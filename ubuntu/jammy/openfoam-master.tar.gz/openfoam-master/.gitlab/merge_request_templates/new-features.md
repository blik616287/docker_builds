### Summary

(Summarize the changes concisely)


### Resolved bugs (If applicable)

(Links to issues)


### Details of new models (If applicable)

(New options, user inputs etc)
(Images are nice :))


### Risks

(Possible regressions?)
(Changes to user inputs?)
